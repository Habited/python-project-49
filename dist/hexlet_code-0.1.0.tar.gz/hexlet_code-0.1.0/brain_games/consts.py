EVEN = 'Answer "yes" if the number is even, otherwise answer "no".'
CALC = "What is the result of the expression?"
GCD = "Find the greatest common divisor of given numbers."
PRIME = 'Answer "yes" if given number is prime. Otherwise answer "no".'
PROGRESSION = "What number is missing in the progression?"
MATHEMATICAL_SYMBOL: list[str, str] = ['+', '-', '*']
NUMBER_OF_ROUNDS = 3
