from brain_games.games.progression import run_progression_games


def main():
    run_progression_games()


if __name__ == "__main__":
    main()
