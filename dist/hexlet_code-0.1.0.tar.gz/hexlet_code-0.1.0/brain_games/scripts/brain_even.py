from brain_games.games.even import run_even_games


def main():
    run_even_games()


if __name__ == "__main__":
    main()
