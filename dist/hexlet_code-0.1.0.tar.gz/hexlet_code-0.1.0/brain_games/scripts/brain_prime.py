from brain_games.games.prime import run_prime_games


def main():
    run_prime_games()


if __name__ == "__main__":
    main()
