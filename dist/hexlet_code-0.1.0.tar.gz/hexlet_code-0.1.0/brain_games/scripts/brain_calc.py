import random
from brain_games.cli import welcom_user