from brain_games.games.calc import run_calc_games


def main():
    run_calc_games()


if __name__ == "__main__":
    main()
