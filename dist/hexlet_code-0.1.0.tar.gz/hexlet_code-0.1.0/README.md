### Hexlet tests and linter status:
[![Actions Status](https://github.com/AlekseyNikolaevS/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AlekseyNikolaevS/python-project-49/actions)

{"version": 2, "width": 80, "height": 24, "timestamp": 1731345146, "env": {"SHELL": "/bin/bash", "TERM": "xterm-256color"}}
[0.014676, "o", "\u001b[?2004h"]
[0.015063, "o", "\u001b]0;habited@habited-BOD-WXX9: ~/Документы/python_project/python-project-49\u0007\u001b[01;32mhabited@habited-BOD-WXX9\u001b[00m:\u001b[01;34m~/Документы/python_project/python-project-49\u001b[00m$ "]
https://asciinema.org/a/ZY1OgXTlupQuvnHJ45qW5RsDC
https://asciinema.org/a/UyTlApCFlCsRRws1hLZkd29Od
https://asciinema.org/a/85DVv57b3z4YAXteRxWzU7TCh
https://asciinema.org/a/AsKVOtd9FVk7biD5DYtMqPA2i
https://asciinema.org/a/UQx4XhZgtSg6Cr5mZqahnqO9X
https://asciinema.org/a/W7O1686OBsg1lKFZPJMgZxAw2
