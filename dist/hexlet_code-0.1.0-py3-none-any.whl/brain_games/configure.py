EVEN = 'Answer "yes" if the number is even, otherwise answer "no".'

NUMBER_OF_ROUNDS = 3
