from brain_games.games.gcd import run_gcd_games


def main():
    run_gcd_games()


if __name__ == "__main__":
    main()
