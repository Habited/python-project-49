#!/usr/bin/env python3
from brain_games.cli import welcom_user


def main():
    welcom_user()


if __name__ == '__main__':
    main()
