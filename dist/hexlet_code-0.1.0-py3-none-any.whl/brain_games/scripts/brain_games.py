#!/usr/bin/env python3
from brain_games.cli import welcom_user
from brain_games.scripts.brain_even import game_logic_parity_check



def main():
    game_logic_parity_check()



if __name__ == '__main__':
    main()
