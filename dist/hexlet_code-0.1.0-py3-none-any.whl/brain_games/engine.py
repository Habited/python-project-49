import prompt


def run_games(instruction, number_of_rounds,
              get_answer_and_player_responce):
    name: str = prompt.string('"Welcome to the Brain Games!"'
                              'May I have your name? ')
    print(f'Hello, {name}!'
          f'{instruction}')

    for _ in range(number_of_rounds):
        correct_answer, player_responce = get_answer_and_player_responce()
        if correct_answer == player_responce:
            print('Correct!')
        else:
            print(f"'{player_responce}' is wrong answer ;(."
                  f"'Correct answer was '{correct_answer}'.\n"
                  f"Let's try again, {name}!")
            return

    print(f'Congratulations, {name}')
